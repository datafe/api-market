# Change Log

All notable changes to the "public-dataset" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

--------------------------------------------------------------------
## [Unreleased]
none

---------------------------------------------------------------------

## V1.0.1
1. Support i18n

## V1.0.0
### Added
1. 初始化

