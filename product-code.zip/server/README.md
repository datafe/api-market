
## Init Server

Initiate server dependencies

```bash
# needs to install Node.js first
npm install --global yarn
yarn install
```


## Run

web resources locate in ../client/dist

```bash
yarn start
```

open http://localhost:3001


